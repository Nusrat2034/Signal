import os
import numpy as np
import matplotlib.pyplot as plt

folder_name = "continuous"
if not os.path.exists(folder_name):
    os.makedirs(folder_name)

class ContinuousSignal:
    def __init__(self, func, INF=np.inf):
        self.func = func
        self.INF = INF

    def shift(self, shift):
        return ContinuousSignal(lambda t: self.func(t - shift), self.INF)

    def add(self, other):
        return ContinuousSignal(lambda t: self.func(t) + other.func(t), self.INF)

    def multiply(self, other):
        return ContinuousSignal(lambda t: self.func(t) * other.func(t), self.INF)

    def multiply_const_factor(self, scalar):
        return ContinuousSignal(lambda t: scalar * self.func(t), self.INF)

    def plot(self, filename, title, additional_func=None, label=None):
        t_values = np.linspace(-self.INF, self.INF, 1000)
        plt.plot(t_values, self.func(t_values), label="Reconstructed", linewidth=2)
        if additional_func is not None:
            plt.plot(t_values, additional_func(t_values), label=label, color="orange", linewidth=2)

        # Final plot settings
        plt.xlabel("t (Time)")
        plt.ylabel("x(t)")
        plt.title(title)
        plt.xlim(-self.INF, self.INF)
        plt.legend(loc="upper right")
        plt.grid(True)

        # Save the plot
        plt.savefig(os.path.join(folder_name, filename))
        plt.show()

class LTI_Continuous:
    def __init__(self, impulse_response, INF=np.inf):
        self.impulse_response = impulse_response
        self.INF = INF
        
    def linear_combination_of_impulses(self, input_signal, delta):
        t_values = np.arange(-self.INF, self.INF, delta)
        coefficients = input_signal.func(t_values) * delta
        impulse_function = lambda t: sum(
            np.where((t_val <= t) & (t < t_val + delta), coeff / delta, 0)
            for t_val, coeff in zip(t_values, coefficients)
        )
        return impulse_function, coefficients

    def plot_linear_combination(self, input_signal, delta, filename):
        impulse_function, coefficients = self.linear_combination_of_impulses(input_signal, delta)
        reconstructed_signal = ContinuousSignal(impulse_function, INF=self.INF)
        reconstructed_signal.plot(filename, title=f"Linear Combination of Impulses (Δ = {delta})", additional_func=input_signal.func, label="x(t)")

    def output_approx(self, input_signal, delta):
        t_values = np.arange(-self.INF, self.INF, delta)
        coefficients = input_signal.func(t_values)
        returned_impulses = []
        for t_val, coeff in zip(t_values, coefficients):
            shifted_impulse_response = self.impulse_response.shift(t_val)
            scaled_impulse_response = ContinuousSignal(lambda t: coeff * delta * shifted_impulse_response.func(t), INF=self.INF)
            returned_impulses.append(scaled_impulse_response)
        return returned_impulses, coefficients

    def plot_output_approx(self, input_signal, delta, filename):
        returned_impulses, coefficients = self.output_approx(input_signal, delta)
        output_signal = ContinuousSignal(lambda t: sum(impulse.func(t) for impulse in returned_impulses), INF=self.INF)
        output_signal.plot(filename, title=f"Output Approximation (Δ = {delta})")
