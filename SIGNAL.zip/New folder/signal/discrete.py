import numpy as np
import matplotlib.pyplot as plt
import os

class DiscreteSignal:
    def __init__(self, values, INF):
        self.values = np.clip(values, -INF, INF)
        self.INF = INF

    def set_value_at_time(self, time, value):
        if time < len(self.values):
            self.values[time] = np.clip(value, -self.INF, self.INF)

    def shift_signal(self, shift):
        if shift > 0:
            shifted_values = np.concatenate((np.zeros(shift), self.values[:-shift]))
        elif shift < 0:
            shifted_values = np.concatenate((self.values[-shift:], np.zeros(-shift)))
        else:
            shifted_values = self.values

        return DiscreteSignal(shifted_values, self.INF)

    def add(self, other):
        added_values = np.clip(self.values + other.values, -self.INF, self.INF)
        return DiscreteSignal(added_values, self.INF)

    def multiply(self, other):
        multiplied_values = np.clip(self.values * other.values, -self.INF, self.INF)
        return DiscreteSignal(multiplied_values, self.INF)

    def multiply_const_factor(self, scaler):
        scaled_values = np.clip(self.values * scaler, -self.INF, self.INF)
        return DiscreteSignal(scaled_values, self.INF)

    def plot(self, title="Discrete Signal", file_name=None, ax=None):
        n = np.arange(-len(self.values) // 2 + 1, len(self.values) // 2 + 1)
        if ax is None:
            plt.stem(n, self.values, basefmt="r-")
            plt.xlabel('n (Time Index)')
            plt.ylabel('x[n]')
            plt.title(title)
            plt.grid(True)
            if file_name:
                plt.savefig(os.path.join('discrete', file_name))
            plt.show()
        else:
            ax.stem(n, self.values, basefmt="r-")
            ax.set_xlabel('n (Time Index)')
            ax.set_ylabel('x[n]')
            ax.set_title(title)
            ax.grid(True)

class LTI_Discrete:
    def __init__(self, impulse_response):
        self.impulse_response = impulse_response

    def linear_combination_of_impulses(self, input_signal):
        impulses = []
        coefficients = []
        n = len(input_signal.values)
        unit_impulse_values = [0] * n
        unit_impulse_values[n // 2] = 1
        unit_impulse = DiscreteSignal(np.array(unit_impulse_values), input_signal.INF)
        for idx, value in enumerate(input_signal.values):
            shift_amount = idx - n // 2
            shifted_impulse = unit_impulse.shift_signal(shift_amount)
            impulses.append(shifted_impulse)
            coefficients.append(value)

        return impulses, coefficients

    def output(self, input_signal):
        coefficients = []
        impulses = []
        n = len(input_signal.values)
        for idx, value in enumerate(input_signal.values):
            shift_amount = idx - n // 2
            shifted_impulse = self.impulse_response.shift_signal(shift_amount)
            impulses.append(shifted_impulse)
            coefficients.append(value)

        return impulses, coefficients

    def plot_impulses_and_sum_as_subplots(self, impulses, coefficients, title):
        n_plots = len(impulses) + 1 
        n_cols = 3
        n_rows = n_plots // n_cols
        fig, axs = plt.subplots(n_rows, n_cols, figsize=(12, 8))
        fig.suptitle(title, fontsize=16)
        axs = axs.flatten()
        plt.subplots_adjust(wspace=0.5, hspace=0.7)
        total_sum = np.zeros(len(impulses[0].values))
        for idx, (impulse, coef) in enumerate(zip(impulses, coefficients)):
            n = np.arange(-len(impulse.values) // 2, len(impulse.values) // 2)
            shift_amount = idx - len(impulse.values) // 2
            scaled_impulse = impulse.multiply_const_factor(coef)
            total_sum += scaled_impulse.values

            scaled_impulse.plot(
                title=r'$\delta[n - (%d)]x[%d]$' % (shift_amount, shift_amount), 
                ax=axs[idx]
            )
            axs[idx].set_ylim([-1, 4])
        sum_signal = DiscreteSignal(total_sum, impulses[0].INF)
        sum_signal.plot(title="Sum", ax=axs[-1])
        axs[-1].set_ylim([-1, 4])

        for idx in range(n_plots, len(axs)):
            axs[idx].axis('off')

        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        if not os.path.exists('discrete'):
            os.makedirs('discrete')

        plt.savefig(os.path.join('discrete', f"impulse_generate.png"))
        plt.show()

    def plot_response(self, impulses, coefficients, title):
        n_plots = len(impulses) + 1
        n_cols = 3
        n_rows = n_plots // n_cols
        fig, axs = plt.subplots(n_rows, n_cols, figsize=(12, 8))
        fig.suptitle(title, fontsize=16)
        axs = axs.flatten()
        plt.subplots_adjust(wspace=0.5, hspace=0.7) 

        total_sum = np.zeros(len(impulses[0].values))
        for idx, (impulse, coef) in enumerate(zip(impulses, coefficients)):
            n = np.arange(-len(impulse.values) // 2, len(impulse.values) // 2)
            shift_amount = idx - len(impulse.values) // 2
            scaled_impulse = impulse.multiply_const_factor(coef)
            total_sum += scaled_impulse.values
            scaled_impulse.plot(
                title=r'$h[n - (%d)]*x[%d]$' % (shift_amount, shift_amount), 
                ax=axs[idx]
            )
            axs[idx].set_ylim([-1, 4])

        sum_signal = DiscreteSignal(total_sum, impulses[0].INF)
        sum_signal.plot(title="Output=Sum", ax=axs[-1])
        axs[-1].set_ylim([-1, 4])

        for idx in range(n_plots, len(axs)):
            axs[idx].axis('off')

        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        if not os.path.exists('discrete'):
            os.makedirs('discrete')

        plt.savefig(os.path.join('discrete', f"output.png"))
        plt.show()
