import numpy as np
import matplotlib.pyplot as plt
import os
from continuous import ContinuousSignal
from continuous import LTI_Continuous
from discrete import DiscreteSignal
from discrete import LTI_Discrete

values = np.array([0, 0, 0, 0, 0, 0.5, 2, 0, 0, 0, 0])
INF = 5
input_signal = DiscreteSignal(values, INF)
input_signal.plot("Input Discrete Signal","input")

impulse_values = np.array([0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0])
impulse_response = DiscreteSignal(impulse_values, INF)
impulse_response.plot("Impulse Response","impulse response")

lti_system = LTI_Discrete(impulse_response)

impulses, coefficients = lti_system.linear_combination_of_impulses(input_signal)
lti_system.plot_impulses_and_sum_as_subplots(impulses, coefficients, "Impulses multiplied by coefficients")

impulses2, coefficients2 = lti_system.output(input_signal)
lti_system.plot_response(impulses2, coefficients2, "Response of Input signal")


input_signal_func = lambda t: np.where(t < 0, 0, np.exp(-t))
input_signal = ContinuousSignal(input_signal_func, INF=3.0)

  
plot_filename = "continuous_signal_plot.png"
input_signal.plot(plot_filename, "Input signal")