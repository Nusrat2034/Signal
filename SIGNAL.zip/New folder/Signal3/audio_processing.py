import numpy as np
import scipy.io.wavfile as wavfile
import matplotlib.pyplot as plt

# Step 1: Load the audio file
sample_rate, data = wavfile.read('buzzjc.wav')  # Replace with your audio file
data = data / np.max(np.abs(data))  # Normalize to -1 to 1

# If stereo, convert to mono by averaging channels
if len(data.shape) > 1:
    data = data.mean(axis=1)

# Step 1.1: Plot the original audio signal in the time domain
plt.figure(figsize=(12, 4))
time = np.linspace(0, len(data) / sample_rate, num=len(data))
plt.plot(time, data)
plt.title("Original Audio Signal (Time Domain)")
plt.xlabel("Time (s)")
plt.ylabel("Amplitude")
plt.show()

# Set parameters for interval sampling and FT
interval_step = 1  # Adjust for sampling every 'interval_step' data points
data_sampled = data[::interval_step]
max_time = len(data_sampled) / (sample_rate / interval_step)
sampled_times = np.linspace(0, max_time, num=len(data_sampled))

# Define frequency range for the FT
max_freq = sample_rate / (2 * interval_step)
num_freqs = len(data_sampled)
frequencies = np.linspace(0, max_freq, num=num_freqs)

def fourier_transform(signal, frequencies, sampled_times):
    num_freqs = len(frequencies)
    ft_result_real = np.zeros(num_freqs)
    ft_result_imag = np.zeros(num_freqs)
    dt = sampled_times[1] - sampled_times[0]  # Time step

    for i, freq in enumerate(frequencies):
        ft_result_real[i] = np.trapz(signal * np.cos(2 * np.pi * freq * sampled_times), dx=dt)
        ft_result_imag[i] = np.trapz(signal *(-1)* np.sin(2 * np.pi * freq * sampled_times), dx=dt)

    return ft_result_real, ft_result_imag

def inverse_fourier_transform(ft_signal, frequencies, sampled_times):
    ft_real, ft_imag = ft_signal
    n = len(sampled_times)
    reconstructed_signal = np.zeros(n)
    freq_step = frequencies[1] - frequencies[0] 

    for i, t in enumerate(sampled_times):
        sum_real = np.sum(
            ft_real * np.cos(2 * np.pi * frequencies * t) - 
            ft_imag * np.sin(2 * np.pi * frequencies * t)
        )
        reconstructed_signal[i] = sum_real * freq_step

    return reconstructed_signal

ft_data = fourier_transform(data_sampled, frequencies, sampled_times)
# Step 2.1: Visualize the frequency spectrum
plt.figure(figsize=(12, 6))
plt.plot(frequencies, np.sqrt(ft_data[0]**2 + ft_data[1]**2))
plt.title("Frequency Spectrum of the Audio Signal (Custom FT with Trapezoidal Integration)")
plt.xlabel("Frequency (Hz)")
plt.ylabel("Magnitude")
plt.show()


filter_range = (frequencies >= 50) & (frequencies <= 1000)
ft_data[0][filter_range] = 0
ft_data[1][filter_range] = 0  

# Step 2.2: Visualize the frequency spectrum after filtering
ft_magnitude = np.sqrt(ft_data[0]**2 + ft_data[1]**2)  # Magnitude = sqrt(real^2 + imag^2)
plt.figure(figsize=(12, 6))
plt.plot(frequencies, ft_magnitude, color="purple")
plt.title("Filtered Frequency Spectrum (50 Hz to 1000 Hz removed)")
plt.xlabel("Frequency (Hz)")
plt.ylabel("Magnitude")
plt.grid()
plt.show()

# Step 3: Apply Inverse Fourier Transform using trapezoidal integration
filtered_data = inverse_fourier_transform(ft_data, frequencies, sampled_times)

# Step 3.1: Plot the reconstructed (denoised) audio signal in the time domain
plt.figure(figsize=(12, 4))
plt.plot(sampled_times, filtered_data)
plt.title("Reconstructed (Denoised) Audio Signal (Time Domain)")
plt.xlabel("Time (s)")
plt.ylabel("Amplitude")
plt.show()

# Step 4: Normalize and save the denoised audio
filtered_data = np.int16(filtered_data / np.max(np.abs(filtered_data)) * 32767)  # Convert to int16 format for WAV
wavfile.write('denoised_audio.wav', sample_rate, filtered_data)

print("Denoised audio saved as 'denoised_audio.wav'")