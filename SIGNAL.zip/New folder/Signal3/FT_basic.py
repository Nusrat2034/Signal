import numpy as np
import matplotlib.pyplot as plt

functions = {
    "Parabolic": lambda x: np.where((x >= -2) & (x <= 2), x**2, 0),
    "Triangular": lambda x: np.where((x >= -2) & (x <= 2), 1 - np.abs(x / 2), 0),
    "Sawtooth": lambda x: np.where((x >= -2) & (x <= 2), (x + 2) / 4, 0),
    "Rectangular": lambda x: np.where((x >= -2) & (x <= 2), 1, 0),
}
x_values = np.linspace(-10, 10, 1000)
frequencies = np.linspace(-5, 5, 500)
sampled_time=x_values

def fourier_transform(signal, frequencies, sampled_times):
    num_freqs = len(frequencies)
    ft_result_real = np.zeros(num_freqs)
    ft_result_imag = np.zeros(num_freqs)
    dt = sampled_times[1] - sampled_times[0] 

    for i, freq in enumerate(frequencies):
        ft_result_real[i] = np.trapz(signal * np.cos(2 * np.pi * freq * sampled_times), dx=dt)
        ft_result_imag[i] = np.trapz(signal *(-1)* np.sin(2 * np.pi * freq * sampled_times), dx=dt)

    return ft_result_real, ft_result_imag

def inverse_fourier_transform(ft_signal, frequencies, sampled_times):
    ft_real, ft_imag = ft_signal
    n = len(sampled_times)
    reconstructed_signal = np.zeros(n)
    freq_step = frequencies[1] - frequencies[0] 

    for i, t in enumerate(sampled_times):
        sum_real = np.sum(
            ft_real * np.cos(2 * np.pi * frequencies * t) - 
            ft_imag * np.sin(2 * np.pi * frequencies * t)
        )
        reconstructed_signal[i] = sum_real * freq_step

    return reconstructed_signal

for name, func in functions.items():
    y_values = func(x_values)

    # Plot the original function
    plt.figure(figsize=(12, 4))
    plt.plot(x_values, y_values, label=f"Original {name}", color="blue")
    plt.title(f"Original Function ({name})")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.grid()
    plt.show()

    # Apply Fourier Transform
    ft_data = fourier_transform(y_values, frequencies, x_values)

    # Plot the frequency spectrum (magnitude of FT)
    ft_magnitude = np.sqrt(ft_data[0]**2 + ft_data[1]**2)  # Magnitude = sqrt(real^2 + imag^2)
    plt.figure(figsize=(12, 6))
    plt.plot(frequencies, ft_magnitude, color="purple")
    plt.title(f"Frequency Spectrum of {name}")
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Magnitude")
    plt.grid()
    plt.show()

    # Reconstruct the signal from the FT data
    reconstructed_y_values = inverse_fourier_transform(ft_data, frequencies, x_values)

    # Plot the original and reconstructed functions
    plt.figure(figsize=(12, 4))
    plt.plot(x_values, y_values, label=f"Original {name}", color="blue")
    plt.plot(x_values, reconstructed_y_values, label=f"Reconstructed {name}", color="red", linestyle="--")
    plt.title(f"Original vs Reconstructed Function ({name})")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.grid()
    plt.show()