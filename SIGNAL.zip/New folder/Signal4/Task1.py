import numpy as np
import matplotlib.pyplot as plt

# Function to generate signals with random shift and noise
def generate_signals(frequency=5, sampling_rate=100, n=50):
    noise_freqs_A = [15, 30, 45]
    amplitudes_A = [0.5, 0.3, 0.1]
    noise_freqs_B = [10, 20, 40]
    amplitudes_B = [0.3, 0.2, 0.1]
    
    dt = 1 / sampling_rate
    time = np.arange(n) * dt
    
    original_signal = np.sin(2 * np.pi * frequency * time)
    
    noise_A = sum(amp * np.sin(2 * np.pi * freq * time) 
                  for freq, amp in zip(noise_freqs_A, amplitudes_A))
    signal_A = original_signal + noise_A
    
    noise_B = sum(amp * np.sin(2 * np.pi * freq * time) 
                  for freq, amp in zip(noise_freqs_B, amplitudes_B))
    noisy_signal_B = signal_A + noise_B
    
    shift_samples = np.random.randint(-n // 2, n // 2)
    print(f"Shift Samples: {shift_samples}")
    signal_B = np.roll(noisy_signal_B, shift_samples)
    
    return signal_A, signal_B

# Function to compute the DFT
def dft(signal):
    N = len(signal)
    return np.array([sum(signal[n] * np.exp(-2j * np.pi * k * n / N) for n in range(N)) for k in range(N)])

# Function to compute the IDFT
def idft(spectrum):
    N = len(spectrum)
    return np.array([sum(spectrum[k] * np.exp(2j * np.pi * k * n / N) for k in range(N)) / N for n in range(N)])

# Function to compute cross-correlation using DFT and IDFT
# Updated cross-correlation using DFT (avoiding circular correlation)
def cross_correlation(signal_A, signal_B):
    dft_A = dft(signal_A)
    dft_B = dft(signal_B)
    conj_dft_B = np.conjugate(dft_B)
    cross_corr_freq = dft_A * conj_dft_B
    cross_corr_time = idft(cross_corr_freq)
    return np.real(cross_corr_time)

# Function to find the sample lag
def find_sample_lag(cross_corr):
    lag = np.argmax(cross_corr)
    if lag > len(cross_corr) // 2:
        lag -= len(cross_corr)
    return lag

# Function to plot signals A and B
def plot_signals(signal_A, signal_B):
    plt.figure(figsize=(10, 5))
    
    # Plot Signal A
    plt.subplot(2, 1, 1)
    plt.stem(signal_A, linefmt='b', markerfmt='bo', basefmt=" ", label="Signal A")
    plt.xlabel("Sample Index (n)")
    plt.ylabel("Amplitude")
    plt.title("Signal A (Station A)")
    plt.legend()

    # Plot Signal B
    plt.subplot(2, 1, 2)
    plt.stem(signal_B, linefmt='r', markerfmt='ro', basefmt=" ", label="Signal B")
    plt.xlabel("Sample Index (n)")
    plt.ylabel("Amplitude")
    plt.title("Signal B (Station B)")
    plt.legend()
    
    plt.tight_layout()
    plt.show()

# Function to plot magnitude spectrum of signals A and B
def plot_magnitude_spectrum(signal_A, signal_B):
    dft_A = np.abs(dft(signal_A))
    dft_B = np.abs(dft(signal_B))
    
    plt.figure(figsize=(10, 5))
    
    # Plot Magnitude Spectrum of Signal A
    plt.subplot(2, 1, 1)
    plt.stem(dft_A, linefmt='b', markerfmt='bo', basefmt=" ", label="Spectrum A")
    plt.xlabel("Sample Index")
    plt.ylabel("Amplitude")
    plt.title("Magnitude Spectrum of Signal A")
    plt.legend()

    # Plot Magnitude Spectrum of Signal B
    plt.subplot(2, 1, 2)
    plt.stem(dft_B, linefmt='r', markerfmt='ro', basefmt=" ", label="Spectrum B")
    plt.xlabel("Sample Index")
    plt.ylabel("Amplitude")
    plt.title("Magnitude Spectrum of Signal B")
    plt.legend()
    
    plt.tight_layout()
    plt.show()

# Function to plot cross-correlation
def plot_cross_correlation(cross_corr):
    plt.figure(figsize=(8, 4))
    plt.stem(cross_corr, linefmt='g', markerfmt='go', basefmt=" ")
    plt.xlabel("Lag (samples)")
    plt.ylabel("Correlation")
    plt.title("Cross-Correlation of Signal A and Signal B")
    plt.show()

# Main function to run the analysis
def main(signal_A, signal_B, sampling_rate, wave_velocity):
    cross_corr = cross_correlation(signal_A, signal_B)
    sample_lag = find_sample_lag(cross_corr)
    time_delay = abs(sample_lag) / sampling_rate
    distance = time_delay * wave_velocity
    
    print(f"Sample Lag: {sample_lag}")
    print(f"Time Delay: {time_delay:.5f} seconds")
    print(f"Estimated Distance: {distance:.2f} meters")
    
    # Plot all graphs
    plot_signals(signal_A, signal_B)                # Plot 1 & 2: Signal A and Signal B
    plot_magnitude_spectrum(signal_A, signal_B)     # Plot 3 & 4: Magnitude Spectrum of Signal A and Signal B
    plot_cross_correlation(cross_corr)              # Plot 5: Cross-Correlation

# Set parameters and run the program
sampling_rate = 100  # Hz
wave_velocity = 8000  # m/s
signal_A, signal_B = generate_signals(frequency=5, sampling_rate=sampling_rate, n=50)
main(signal_A, signal_B, sampling_rate, wave_velocity)