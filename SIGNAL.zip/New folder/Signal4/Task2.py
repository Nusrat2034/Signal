import numpy as np
import time
import matplotlib.pyplot as plt

# DFT Implementation
def dft(signal):
    N = len(signal)
    return np.array([sum(signal[n] * np.exp(-2j * np.pi * k * n / N) for n in range(N)) for k in range(N)])

# IDFT Implementation
def idft(spectrum):
    N = len(spectrum)
    return np.array([sum(spectrum[k] * np.exp(2j * np.pi * k * n / N) for k in range(N)) / N for n in range(N)])

# FFT Implementation
def fft(signal):
    N = len(signal)
    if N <= 1:
        return signal
    even = fft(signal[::2])
    odd = fft(signal[1::2])
    factor = [np.exp(-2j * np.pi * k / N) for k in range(N // 2)]
    return np.array([even[k] + factor[k] * odd[k] for k in range(N // 2)] +
                    [even[k] - factor[k] * odd[k] for k in range(N // 2)])

# IFFT Implementation
def ifft(spectrum):
    N = len(spectrum)
    if N <= 1:
        return spectrum
    even = ifft(spectrum[::2])
    odd = ifft(spectrum[1::2])
    factor = [np.exp(2j * np.pi * k / N) for k in range(N // 2)]
    return np.array([(even[k] + factor[k] * odd[k]) / 2 for k in range(N // 2)] +
                    [(even[k] - factor[k] * odd[k]) / 2 for k in range(N // 2)])

# Measure runtime of a function
def measure_runtime(func, *args, repetitions=10):
    start = time.time()
    for _ in range(repetitions):
        func(*args)
    return (time.time() - start) / repetitions

# Main comparison function
def compare_dft_fft():
    n_values = [2**k for k in range(4, 10)]  # Input sizes (powers of 2 from 16 to 512)
    dft_times, fft_times, idft_times, ifft_times = [], [], [], []

    for n in n_values:
        signal = np.random.random(n)  # Generate random signal

        # Measure DFT and FFT runtimes
        dft_times.append(measure_runtime(dft, signal))
        fft_times.append(measure_runtime(fft, signal))

        # Measure IDFT and IFFT runtimes
        transformed_signal = dft(signal)
        transformed_signal_fft = fft(signal)
        idft_times.append(measure_runtime(idft, transformed_signal))
        ifft_times.append(measure_runtime(ifft, transformed_signal_fft))

        # Verify reconstruction correctness
        assert np.allclose(signal, idft(transformed_signal), atol=1e-10), "IDFT failed!"
        assert np.allclose(signal, ifft(transformed_signal_fft), atol=1e-10), "IFFT failed!"

    # Plot runtime comparisons
    plt.figure(figsize=(12, 6))
    plt.plot(n_values, dft_times, label='DFT', marker='o', linestyle='--')
    plt.plot(n_values, fft_times, label='FFT', marker='o', linestyle='-')
    plt.plot(n_values, idft_times, label='IDFT', marker='x', linestyle='--')
    plt.plot(n_values, ifft_times, label='IFFT', marker='x', linestyle='-')
    plt.xlabel('Number of Samples (n)')
    plt.ylabel('Average Runtime (seconds)')
    plt.title('Runtime Comparison: DFT/FFT and IDFT/IFFT')
    plt.xscale('log', base=2)
    plt.legend()
    plt.grid(True)
    plt.show()

# Execute the comparison
compare_dft_fft()